INSERT INTO note(id,title,content,created,version) VALUES
    (0, 'What I got for Christmas', 'I got a puppy.', '2019-12-25', 1),
    (1, '2018 Christmas Shopping List', 'Switch, Puppy, Blender, Vacuum', '2019-11-25', 3),
    (2, '2018 Easter List', 'Bunnies... bunnies everywhere', '2020-03-25', 10);